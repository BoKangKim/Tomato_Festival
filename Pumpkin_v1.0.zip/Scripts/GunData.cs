using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;
using Photon.Realtime;

public class GunData : MonoBehaviourPun
{
    string DefaultGunName = "Handgun";
    SpriteRenderer gunSprite;
    Animator animator = null;
    ScriptableWeaponData[] GunDatas;
    List<RuntimeAnimatorController> controller = null;
    Animator gunAni = null;
    string playerWeapon = null;

    private void Awake()
    {
        gunAni = GetComponent<Animator>();
        controller = new List<RuntimeAnimatorController>();
        GunDatas = new ScriptableWeaponData[3];
        gunSprite = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        

        GunDatas[0] = Resources.Load<ScriptableWeaponData>("Handgun");
        GunDatas[1] = Resources.Load<ScriptableWeaponData>("Repeater");
        GunDatas[2] = Resources.Load<ScriptableWeaponData>("Shotgun");
        //GunDatas[3] = Resources.Load<ScriptableWeaponData>("SniperRifle");

        controller.Add(Resources.Load<RuntimeAnimatorController>("HandgunController"));
        controller.Add(Resources.Load<RuntimeAnimatorController>("RepeaterController"));
        controller.Add(Resources.Load<RuntimeAnimatorController>("ShotgunController"));
        //controller.Add(Resources.Load<RuntimeAnimatorController>("BaseballController"));
    }

    private void OnEnable()
    {
        if (photonView.IsMine == false)
            return;

        List<string> guns = new List<string>();
        SplitData splitData = FindObjectOfType<SplitData>();

        if (splitData != null && photonView.IsMine)
            guns = splitData.GetAndSplitData("Gun");

        if (guns.Count == 0)
        {
            playerWeapon = DefaultGunName;
        }
        else
        {
            playerWeapon = guns[guns.Count - 1];
        }

        photonView.RPC("RPC_SetGunSprite", RpcTarget.AllBuffered, playerWeapon);
    }

    [PunRPC]
    void RPC_SetGunSprite(string gun)
    {
        for (int i = 0; i < GunDatas.Length; i++)
        {
            if (GunDatas[i].GunName.Equals(gun))
            {
                Gun gunData = GetComponentInChildren<Gun>();
                gunData.SetGunData(GunDatas[i]);
                gunSprite.sprite = GunDatas[i].GunImg;
                gunAni.runtimeAnimatorController = controller[i];
                break;
            }
        }
    }
    
}
