using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;



public class BlockSpawner : MonoBehaviourPun
{
    [Header("���� ����")]
    [SerializeField] List<Scriptable_PinBallBlock> blockDatas;
    [SerializeField] GameObject[] blockLine;

    public Scriptable_PinBallBlock GetBlockData(int idx) { return blockDatas[idx]; }


    Block[,] block;

    [SerializeField] int BlockposYnum = 5;
    [SerializeField] int BlockposXnum = 11;

    Vector3 Pos = Vector3.zero;

    bool isReArrangement = false;
    private void Awake()
    {   
        block = new Block[BlockposYnum, BlockposXnum];
    }

    void Start()
    {
        if (PhotonNetwork.IsMasterClient)
        {
                CreateBlock();
        }
    }

    #region ��������
    public void CreateBlock()
    {
        Pos.x = -30f;
        Pos.y = -3f;
        
        for (int y = 0; y < BlockposYnum; y++)
        {
            
            // ------------------------------------
            //Pos.y += 0.9f;
            Pos.y += 5f;
            //Pos.x = -7.5f;  // �ٽ� x�� �ʱ�ȭ
            Pos.x = -30f;  // �ٽ� x�� �ʱ�ȭ
            // -------------------------------------

            for (int x = 0; x < BlockposXnum; x++)
            {
                int random = Random.Range(0, 100);

                if (random < 20) // ��ź -> 20%
                {
                    block[y, x] = PhotonNetwork.Instantiate("Block", Pos, Quaternion.identity).GetComponent<Block>();
                    block[y, x].blockData = blockDatas[0];
                    block[y, x].RPC_BlockDatas(0);
                }
                else if (random >= 20 && random < 40) // �ǵ� -> 20%
                {
                    block[y, x] = PhotonNetwork.Instantiate("Block", Pos, Quaternion.identity).GetComponent<Block>();
                    block[y, x].blockData = blockDatas[1];
                    block[y, x].RPC_BlockDatas(1);
                }
                else if (random >= 40 && random < 50) // ���� -> 10%
                {
                    block[y, x] = PhotonNetwork.Instantiate("Block", Pos, Quaternion.identity).GetComponent<Block>();
                    block[y, x].blockData = blockDatas[4];
                    block[y, x].RPC_BlockDatas(4);
                }
                else if (random >= 50 && random < 60) // ���� -> 10%
                {
                    block[y, x] = PhotonNetwork.Instantiate("Block", Pos, Quaternion.identity).GetComponent<Block>();
                    block[y, x].blockData = blockDatas[6];
                    block[y, x].RPC_BlockDatas(6);
                }
                else // 50% �Ѿ� -> 40%
                {
                    block[y, x] = PhotonNetwork.Instantiate("Block", Pos, Quaternion.identity).GetComponent<Block>();
                    block[y, x].blockData = blockDatas[5];
                    block[y, x].RPC_BlockDatas(5);
                }

                block[y, x].transform.parent = blockLine[y].transform;
                Pos.x += 6f;
            }
        }
    }
    #endregion


    //[PunRPC]
    public Block BackBlock(Vector3 pos)
    {
        Block instblock = null;

        //    // ������ ��� �߿��� ��Ȱ��ȭ �� ���� ã�´�.
        //    // ���� ť������ �� �տ� �ִ� �� �ϳ��� ������ �ָ�

        instblock.transform.SetPositionAndRotation(pos, Quaternion.identity);
        instblock.gameObject.SetActive(true);
        return instblock;
    }


    public void recycle(int i)
    {
        Vector2 PosyY = new Vector2(-30f, 22f);

        for (int x = 0; x < BlockposXnum; x++)
        {
            //block[4, x] = Pos;
            int random = Random.Range(0, 100);

            if (random < 20) // ��ź -> 20%
            {
                block[4, x] = PhotonNetwork.Instantiate("Block", PosyY, Quaternion.identity).GetComponent<Block>();
                block[4, x].blockData = blockDatas[0];
                block[4, x].RPC_BlockDatas(0);
            }
            else if (random >=20 && random < 40) // �ǵ� -> 20%
            {
                block[4, x] = PhotonNetwork.Instantiate("Block", PosyY, Quaternion.identity).GetComponent<Block>();
                block[4, x].blockData = blockDatas[1];
                block[4, x].RPC_BlockDatas(1);
            }
            else if (random >=40 && random < 50) // ���� -> 10%
            {
                block[4, x] = PhotonNetwork.Instantiate("Block", PosyY, Quaternion.identity).GetComponent<Block>();
                block[4, x].blockData = blockDatas[4];
                block[4, x].RPC_BlockDatas(4);
            }
            else if (random >= 50 && random < 60) // ���� -> 10%
            {
                block[4, x] = PhotonNetwork.Instantiate("Block", PosyY, Quaternion.identity).GetComponent<Block>();
                block[4, x].blockData = blockDatas[6];
                block[4, x].RPC_BlockDatas(6);
            }
            else // 50% �Ѿ� -> 40%
            {
                block[4, x] = PhotonNetwork.Instantiate("Block", PosyY, Quaternion.identity).GetComponent<Block>();
                block[4, x].blockData = blockDatas[5];
                block[4, x].RPC_BlockDatas(5);
            }

            PosyY.x += 6f;


            block[4, x].transform.parent = blockLine[i].transform;
        }
    }


    void Update()
    {
        if (PhotonNetwork.IsMasterClient == false)
            return;

        if (PhotonNetwork.IsMasterClient)
        {
            // ����� array�� ����
            GameObject[] _blockLine = new GameObject[5];

            #region ù��° ��������
            // ù��° ���������� �ٱ�������
            if (blockLine[0].transform.childCount == 0)
            {
                isReArrangement = true;

                // ������ �����ĵ� ������ ���縦 �س���
                _blockLine[4] = blockLine[0];
                _blockLine[0] = blockLine[1];
                _blockLine[1] = blockLine[2];
                _blockLine[2] = blockLine[3];
                _blockLine[3] = blockLine[4];

                // 5���� ���������� ������
                for (int i = 0; i < blockLine.Length; i++)
                {
                    blockLine[i].transform.position -= new Vector3(0, 6f);
                }

                // ������ 2���� �迭�� ������
                for (int y = 0; y < BlockposYnum; y++)
                {
                    for (int x = 0; x < BlockposXnum; x++)
                    {
                        if (y > 0)
                        {
                            block[y, x] = block[y - 1, x];
                        }
                        if (y == 0)
                        {
                            block[y, x] = block[4, x];
                        }
                    }
                }

                // ��Ȱ��ȭ �� ���������� ������ �ø��� ������ �����
                recycle(0);

                // �������ο� �迭 ���� ������
                blockLine[0] = _blockLine[0];
                blockLine[1] = _blockLine[1];
                blockLine[2] = _blockLine[2];
                blockLine[3] = _blockLine[3];
                blockLine[4] = _blockLine[4];

            }

            #endregion
            #region �ι�° ��������
            if (blockLine[1].transform.childCount == 0)
            {
                isReArrangement = true;
                // 4���� ���������� ������

                _blockLine[4] = blockLine[1];
                _blockLine[1] = blockLine[2];
                _blockLine[2] = blockLine[3];
                _blockLine[3] = blockLine[4];

                for (int i = 1; i < blockLine.Length; i++)
                {
                    blockLine[i].transform.position -= new Vector3(0, 5f);
                }

                // ������ 2���� �迭�� ������
                for (int y = 1; y < BlockposYnum; y++)
                {
                    for (int x = 0; x < BlockposXnum; x++)
                    {
                        if (y > 1)
                        {
                            block[y, x] = block[y - 1, x];
                        }
                        if (y == 1)
                        {
                            block[y, x] = block[4, x];
                        }
                    }
                }
                Vector2 PosyY = new Vector2(-14f, 10.5f);

                recycle(1);
                blockLine[1] = _blockLine[1];
                blockLine[2] = _blockLine[2];
                blockLine[3] = _blockLine[3];
                blockLine[4] = _blockLine[4];

            }
            #endregion
            #region ����° ��������
            if (blockLine[2].transform.childCount == 0)
            {
                isReArrangement = true;

                _blockLine[4] = blockLine[2];
                _blockLine[2] = blockLine[3];
                _blockLine[3] = blockLine[4];


                for (int i = 2; i < blockLine.Length; i++)
                {
                    blockLine[i].transform.position -= new Vector3(0, 5f);
                }

                // ������ 2���� �迭�� ������
                for (int y = 2; y < BlockposYnum; y++)
                {
                    for (int x = 0; x < BlockposXnum; x++)
                    {
                        if (y > 2)
                        {
                            block[y, x] = block[y - 1, x];
                        }
                        if (y == 2)
                        {
                            block[y, x] = block[4, x];
                        }
                    }
                }

                Vector2 PosyY = new Vector2(-14f, 10.5f);

                // ��Ȱ��ȭ �� ���������� ������ �ø��� ������ �����
                recycle(2);

                // �������ο� �迭 ���ڰ� �ٲ�

                blockLine[2] = _blockLine[2];
                blockLine[3] = _blockLine[3];
                blockLine[4] = _blockLine[4];

            }
            #endregion
            #region �׹�° ��������
            if (blockLine[3].transform.childCount == 0)
            {
                isReArrangement = true;
                // 2���� ���������� ������


                _blockLine[4] = blockLine[3];
                _blockLine[3] = blockLine[4];


                for (int i = 3; i < blockLine.Length; i++)
                {
                    blockLine[i].transform.position -= new Vector3(0, 5f);
                }

                // ������ 2���� �迭�� ������
                for (int y = 3; y < BlockposYnum; y++)
                {
                    for (int x = 0; x < BlockposXnum; x++)
                    {
                        if (y > 3)
                        {
                            block[y, x] = block[y - 1, x];
                        }
                        if (y == 3)
                        {
                            block[y, x] = block[4, x];
                        }
                    }
                }
                Vector2 PosyY = new Vector2(-14f, 10.5f);
                // ��Ȱ��ȭ �� ���������� ������ �ø��� ������ �����
                recycle(3);
                photonView.RPC("recycle", RpcTarget.All, 3);

                // �������ο� �迭 ���ڰ� �ٲ�

                blockLine[3] = _blockLine[3];
                blockLine[4] = _blockLine[4];
            }
            #endregion

            if (isReArrangement == true)
            {
                Block[] blocks = FindObjectsOfType<Block>();
                for (int i = 0; i < blocks.Length; i++)
                {
                    blocks[i].photonView.RPC("BlockTransFormChange", RpcTarget.Others, blocks[i].gameObject.transform.position);
                }

                isReArrangement = false;
            }
        }

    }
}
